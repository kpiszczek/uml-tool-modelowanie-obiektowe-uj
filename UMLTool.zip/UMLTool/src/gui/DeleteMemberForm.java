/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gui;

import data.Entity;
import data.Member;
import data.DataVector;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JComboBox;
/**
 *
 * @author kuba
 */
public class DeleteMemberForm extends JFrame implements ActionListener{
    private JComboBox members;
    private JButton deleteButton;
    private JButton cancelButton;

    DeleteMemberForm(){
        Container contentPane = getContentPane();
        contentPane.setLayout(new GridLayout(0,2));

        contentPane.add(new JLabel("Member"));
        members = new JComboBox();
        Entity entity = DataVector.getInstance().getActiveEntity();
        if (entity != null){
            for (Member member: entity.getMembers()){
                members.addItem(member.getName());
            }
        }
        contentPane.add(members);

        deleteButton = new JButton("Delete");
        deleteButton.addActionListener(this);
        contentPane.add(deleteButton);

        cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(this);
        contentPane.add(cancelButton);

        setVisible(true);
        setSize(getPreferredSize());
    }

    public void actionPerformed(ActionEvent e){
        JButton button = (JButton) e.getSource();

        if(button == deleteButton){
            String n = this.members.getSelectedItem().toString();

            if(!n.isEmpty())
            {
                Entity entity = DataVector.getInstance().getActiveEntity();
                if (entity != null){
                    Member m = entity.getMember(n);
                    if (m!=null){
                       entity.getMembers().remove(m);
                        DataVector.getInstance().repaint();
                    }
                }
            }
        }
        setVisible(false);
    }
}
