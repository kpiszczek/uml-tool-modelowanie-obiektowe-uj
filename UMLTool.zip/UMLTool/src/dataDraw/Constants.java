/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package dataDraw;

/**
 *
 * @author SG0217432
 */
public interface Constants {
    public static final int MARGIN = 2;
    public static final int TRIANGLE_H = 10;
    public static final int TRIANGLE_HALF_A = 6;
    public static final int RHOMB_H1 = 12;
    public static final int RHOMB_H2 = 7;

    public static final int MIN_DISTANCE = 40;
    public static final int X_RANDOM = 1024;
    public static final int Y_RANDOM = 768;


}

